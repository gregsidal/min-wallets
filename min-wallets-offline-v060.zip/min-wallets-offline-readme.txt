On an air-gapped device open:

  offline/index.html

Then use the wallet tools to manage wallets and create transactions.

Signed transactions can be saved to a thumb drive or SD card, moved 
to an online device, then safely broadcast to the Ethereum network.

Additional instructions are provided in each tool.
