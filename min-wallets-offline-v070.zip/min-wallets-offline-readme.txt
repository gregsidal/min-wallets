On an air-gapped device open:

  offline/index.html

Then use the wallet tools to manage wallets and sign transactions.

Signed transactions can be displayed as QR codes or saved to text files. 
The QR codes can be quickly scanned and safely broadcast to the network 
using an online device. A thumb drive or SD card can be used to transfer 
transactions saved as text files.

Additional instructions are provided in each tool.

